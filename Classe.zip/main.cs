using System;

namespace exemplo1 {

  class MainClass {
    public static void Main (string[] args) {
      
      Videogame xbox = new Videogame();
      xbox.Ligar();
    }
  }
}